class User:
    def __init__(self, author_id, author_name, author_nick, isBot):
        self.author_id = author_id
        self.author_name = author_name
        self.author_nick = author_nick
        self.isBot = isBot
