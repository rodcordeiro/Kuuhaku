class Channel:
    def __init__(self,channel_id,channel_name,nsfw,news,category_id):
        self.channel_id = channel_id
        self.channel_name = channel_name
        self.nsfw = nsfw
        self.news = news
        self.category_id = category_id
        